exports.guideQRIS = () => {
    return `1. Screenshot kode QR yang tampil
2. Masuk ke aplikasi dompet digital Anda yang telah mendukung QRIS seperti (Dana, Gopay, Ovo, Shopeepay, Link 
aja, Dll)
3. Buka Scan QR pada aplikasi dompet digital anda
4. Scan QR yang muncul pada halaman pembelian anda/ Pilih dari galeri hasil screenshot kode QR
5. Akan muncul detail transaksi. Pastikan data transaksi sudah sesuai
6. Selesaikan proses pembayaran Anda
7. Transaksi selesai. Simpan bukti pembayaran Anda`
}