<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>RAF BOT - Config</title>

  <!-- Custom fonts for this template -->
  <link href="/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="/css/sb-admin-2.min.css" rel="stylesheet">
  <link href="/css/dashboard-modern.css" rel="stylesheet">

  <!-- Custom styles for this page -->
  <link href="/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
  
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>RAF BOT - Config</title>

  <!-- Custom fonts for this template -->
  <link href="/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="/css/sb-admin-2.min.css" rel="stylesheet">
  <link href="/css/dashboard-modern.css" rel="stylesheet">

  <!-- Custom styles for this page -->
  <link href="/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <?php include '_navbar.php'; ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <form class="form-inline">
            <button type="button" id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
              <i class="fa fa-bars"></i>
            </button>
          </form>


          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">


            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Admin</span>
                <img class="img-profile rounded-circle" src="/img/undraw_profile.svg">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <!-- Page Header -->
          <div class="dashboard-header">
            <h1>Perbarui Konfigurasi</h1>
            <p>Kelola dan monitor perbarui konfigurasi</p>
          </div>

          <!-- Mikrotik Devices Configuration -->
          <!-- Table Section -->
          <h4 class="dashboard-section-title">Konfigurasi MikroTik</h4>
          <div class="card table-card mb-4">
            <div class="card-header">
              <h6>Konfigurasi MikroTik</h6>
            </div>
            <div class="card-body">
              <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#mikrotikDeviceModal" id="addMikrotikDeviceBtn">Tambah Perangkat</button>
              <div class="table-responsive">
                <table class="table table-bordered" id="mikrotikDevicesTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>IP Address</th>
                      <th>Username</th>
                      <th>Status</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    <!-- Data will be populated by JavaScript -->
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <!-- DataTales Example -->
          <form id="configForm">
            <!-- Table Section -->
          <h4 class="dashboard-section-title">Konfigurasi Wifi & Bot</h4>
          <div class="card table-card mb-4">
            <div class="card-header">
              <h6>Konfigurasi Wifi & Bot</h6>
              </div>
              <div class="card-body">
                  <div class="mb-3">
                    <label for="nama" class="form-label">Nama Wifi</label>
                    <input type="text" class="form-control" id="nama" name="nama" />
                  </div>
                  <div class="mb-3">
                    <label for="namabot" class="form-label">Nama Bot</label>
                    <input type="text" class="form-control" id="namabot" name="namabot" />
                  </div>
                  <div class="mb-3">
                    <label for="telfon" class="form-label">Nomor Telfon Kontak</label>
                    <input type="text" class="form-control" id="telfon" name="telfon" />
                  </div>
                  <div class="mb-3">
                    <label for="parentbinding" class="form-label">Parent Binding</label>
                    <input type="text" class="form-control" id="parentbinding" name="parentbinding" />
                  </div>
                  <div class="mb-3">
                    <label for="custom_wifi_modification">Mode Kustom Ganti WiFi</label>
                    <select class="form-control" id="custom_wifi_modification" name="custom_wifi_modification">
                        <option value="true">Aktif</option>
                        <option value="false">Nonaktif</option>
                    </select>
                    <small class="form-text text-muted">Jika Aktif, bot akan menawarkan pilihan SSID saat pelanggan (yang punya >1 SSID) ingin ganti nama/sandi. Jika Nonaktif, akan langsung mengubah semua SSID.</small>
                  </div>
                  <div class="mb-3">
                    <label for="sync_to_mikrotik">Sinkronisasi ke MikroTik</label>
                    <select class="form-control" id="sync_to_mikrotik" name="sync_to_mikrotik">
                        <option value="true">Aktif</option>
                        <option value="false">Nonaktif</option>
                    </select>
                    <small class="form-text text-muted">Jika Aktif, perubahan profil pelanggan di halaman user akan otomatis disinkronkan ke MikroTik. Jika Nonaktif, perubahan hanya tersimpan di sistem tanpa mempengaruhi data di MikroTik.</small>
                  </div>
                  <div class="mb-3">
                    <label for="whatsapp_message_delay" class="form-label">Delay Pesan WhatsApp (ms)</label>
                    <input type="number" class="form-control" id="whatsapp_message_delay" name="whatsapp_message_delay" min="500" max="5000" step="100" />
                    <small class="form-text text-muted">Jeda waktu (dalam milidetik) antara pengiriman pesan WhatsApp oleh cron jobs. Default: 2000ms (2 detik). Minimum: 500ms. Digunakan untuk mencegah spam dan rate limiting.</small>
                  </div>
              </div>
            </div>

            <!-- Table Section -->
          <h4 class="dashboard-section-title">Konfigurasi Penagihan & Isolir</h4>
          <div class="card table-card mb-4">
            <div class="card-header">
              <h6>Konfigurasi Penagihan & Isolir</h6>
              </div>
              <div class="card-body">
                  <div class="mb-3">
                    <label for="tanggal_pengingat" class="form-label">Tanggal Pengingat Tagihan (1-28)</label>
                    <input type="number" class="form-control" id="tanggal_pengingat" name="tanggal_pengingat" min="1" max="28" />
                    <small class="form-text text-muted">Notifikasi pengingat akan dikirim mulai tanggal ini setiap bulan.</small>
                  </div>
                  <div class="mb-3">
                    <label for="tanggal_batas_bayar" class="form-label">Tanggal Batas Pembayaran (1-28)</label>
                    <input type="number" class="form-control" id="tanggal_batas_bayar" name="tanggal_batas_bayar" min="1" max="28" />
                     <small class="form-text text-muted">Tanggal terakhir pembayaran. Digunakan sebagai `dueDate` di API.</small>
                  </div>
                  <div class="mb-3">
                    <label for="tanggal_isolir" class="form-label">Tanggal Isolir (1-28)</label>
                    <input type="number" class="form-control" id="tanggal_isolir" name="tanggal_isolir" min="1" max="28" />
                     <small class="form-text text-muted">Pelanggan yang belum bayar akan diisolir mulai tanggal ini.</small>
                  </div>
                  <div class="mb-3">
                    <label for="isolir_profile" class="form-label">Profil PPPoE Isolir</label>
                    <input type="text" class="form-control" id="isolir_profile" name="isolir_profile" />
                    <small class="form-text text-muted">Nama profil di MikroTik untuk pelanggan yang diisolir.</small>
                  </div>
                   <div class="mb-3">
                    <label for="rekening_details" class="form-label">Detail Rekening</label>
                    <textarea class="form-control" id="rekening_details" name="rekening_details" rows="4"></textarea>
                    <small class="form-text text-muted">Informasi rekening yang akan ditampilkan di notifikasi tagihan.</small>
                  </div>
              </div>
            </div>

            <!-- Bank Accounts Section -->
            <div class="card shadow mb-4">
              <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">Rekening Bank</h6>
                <button type="button" class="btn btn-sm btn-success" onclick="addBankAccount()">
                  <i class="fas fa-plus"></i> Tambah Rekening
                </button>
              </div>
              <div class="card-body">
                <div id="bankAccountsList">
                  <!-- Bank accounts will be populated here -->
                </div>
                <small class="form-text text-muted">Rekening bank yang akan ditampilkan untuk pembayaran transfer.</small>
              </div>
            </div>

            <!-- Table Section -->
          <h4 class="dashboard-section-title">Konfigurasi Teknis</h4>
          <div class="card table-card mb-4">
            <div class="card-header">
              <h6>Konfigurasi Teknis</h6>
              </div>
              <div class="card-body">
                  <div class="mb-3">
                    <label for="genieacsBaseUrl" class="form-label">Genieacs URL</label>
                    <input type="text" class="form-control" id="genieacsBaseUrl" name="genieacsBaseUrl" />
                  </div>
                  <div class="mb-3">
                    <label for="accessLimit" class="form-label">Maksimal akses</label>
                    <input type="number" class="form-control" id="accessLimit" name="accessLimit" />
                  </div>
                  <div class="mb-3">
                    <label for="rx_tolerance">Toleransi Redaman</label>
                    <input type="number" class="form-control" id="rx_tolerance" name="rx_tolerance" />
                  </div>
                  <div class="mb-3">
                    <label for="ipaymuSecret">Secret Ipaymu</label>
                    <input type="text" class="form-control" id="ipaymuSecret" name="ipaymuSecret" />
                  </div>
                  <div class="mb-3">
                    <label for="ipaymuVA">VA Ipaymu</label>
                    <input type="text" class="form-control" id="ipaymuVA" name="ipaymuVA" />
                  </div>
                  <div class="mb-3">
                    <label for="ipaymuCallback">Callback Ipaymu</label>
                    <input type="text" class="form-control" id="ipaymuCallback" name="ipaymuCallback" />
                  </div>
                  <div class="mb-3">
                    <label for="ipaymuProduction">Production Ipaymu</label>
                    <input type="text" class="form-control" id="ipaymuProduction" name="ipaymuProduction" />
                  </div>
              </div>
            </div>

            <div class="d-flex w-100 mb-4" style="justify-content: end;">
              <button type="submit" class="btn btn-primary">Simpan Semua Konfigurasi</button>
            </div>
          </form>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2020</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="/logout">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Mikrotik Device Modal -->
<div class="modal fade" id="mikrotikDeviceModal" tabindex="-1" role="dialog" aria-labelledby="mikrotikDeviceModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="mikrotikDeviceModalLabel">Tambah Perangkat MikroTik</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="mikrotikDeviceForm">
          <input type="hidden" id="mikrotikDeviceId" name="id">
          <div class="form-group">
            <label for="mikrotikIp">IP Address</label>
            <input type="text" class="form-control" id="mikrotikIp" name="ip" required>
          </div>
          <div class="form-group">
            <label for="mikrotikName">Username</label>
            <input type="text" class="form-control" id="mikrotikName" name="name" required>
          </div>
          <div class="form-group">
            <label for="mikrotikPassword">Password</label>
            <input type="password" class="form-control" id="mikrotikPassword" name="password" required>
          </div>
          <div class="form-group">
            <label for="mikrotikPort">API Port</label>
            <input type="number" class="form-control" id="mikrotikPort" name="port" placeholder="8728" required>
            <small class="form-text text-muted">Port API di Mikrotik. Default: 8728, SSL: 8729.</small>
          </div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        <button type="button" class="btn btn-primary" id="saveMikrotikDeviceBtn">Simpan</button>
      </div>
    </div>
  </div>
</div>


  <!-- Bootstrap core JavaScript-->
  <script src="/vendor/jquery/jquery.min.js"></script>
  <script src="/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="/js/sb-admin-2.js"></script>

  <!-- Page level plugins -->
  <script src="/vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="/vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const form = document.getElementById('configForm');

      // Fetch initial data
      fetch('/api/config', { credentials: 'include' })
        .then(res => res.json())
        .then(json => {
            if (json.data) {
                // Helper to set value
                const setValue = (id, value, fallback = '') => {
                    const el = document.getElementById(id);
                    if (el) el.value = value || fallback;
                };

                // Set values from json.data
                setValue('nama', json.data.nama);
                setValue('namabot', json.data.namabot);
                setValue('telfon', json.data.telfon);
                setValue('parentbinding', json.data.parentbinding);
                setValue('tanggal_pengingat', json.data.tanggal_pengingat, '1');
                setValue('tanggal_batas_bayar', json.data.tanggal_batas_bayar, '10');
                setValue('tanggal_isolir', json.data.tanggal_isolir, '11');
                setValue('isolir_profile', json.data.isolir_profile);
                setValue('rekening_details', json.data.rekening_details);
                setValue('genieacsBaseUrl', json.data.genieacsBaseUrl);
                setValue('accessLimit', json.data.accessLimit);
                setValue('rx_tolerance', json.data.rx_tolerance);
                setValue('ipaymuSecret', json.data.ipaymuSecret);
                setValue('ipaymuVA', json.data.ipaymuVA);
                setValue('ipaymuCallback', json.data.ipaymuCallback);
                setValue('ipaymuProduction', json.data.ipaymuProduction ? "yes" : "no");
                setValue('custom_wifi_modification', json.data.custom_wifi_modification ? "true" : "false");
                setValue('sync_to_mikrotik', json.data.sync_to_mikrotik ? "true" : "false");
                setValue('whatsapp_message_delay', json.data.whatsapp_message_delay, '2000');
                
                // Load bank accounts
                if (json.data.bankAccounts) {
                    window.bankAccounts = json.data.bankAccounts;
                    displayBankAccounts();
                } else {
                    window.bankAccounts = [];
                }
            }
        })
        .catch(error => {
            console.error("Error fetching initial config:", error);
            Swal.fire({
                icon: 'error',
                title: 'Gagal Memuat',
                text: 'Tidak dapat memuat konfigurasi awal dari server.'
            });
        });

      // Handle form submission
      form.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        
        // Add bank accounts to data
        data.bankAccounts = window.bankAccounts;

        const submitButton = form.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Menyimpan...';

        fetch('/api/config', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include', // ✅ Fixed by script
          body: JSON.stringify(data),
        })
        .then(response => {
            if (!response.ok) {
                // Try to get error message from JSON response
                return response.json().then(err => { throw new Error(err.message || `HTTP error! status: ${response.status}`) });
            }
            return response.json();
        })
        .then(result => {
          Swal.fire({
            icon: 'success',
            title: 'Berhasil!',
            text: result.message || 'Konfigurasi berhasil disimpan.',
            timer: 2000,
            showConfirmButton: false
          });
        })
        .catch(error => {
          console.error('Error:', error);
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: error.message || 'Terjadi kesalahan saat menyimpan konfigurasi!',
          });
        })
        .finally(() => {
            submitButton.disabled = false;
            submitButton.innerHTML = 'Simpan Semua Konfigurasi';
        });
      });

      // Mikrotik Devices Management
      const mikrotikDevicesTable = document.getElementById('mikrotikDevicesTable').getElementsByTagName('tbody')[0];
      const mikrotikDeviceModal = $('#mikrotikDeviceModal');
      const mikrotikDeviceForm = document.getElementById('mikrotikDeviceForm');
      const saveMikrotikDeviceBtn = document.getElementById('saveMikrotikDeviceBtn');

      function loadMikrotikDevices() {
        fetch('/api/mikrotik-devices', { credentials: 'include' })
          .then(res => res.json())
          .then(devices => {
            mikrotikDevicesTable.innerHTML = '';
            devices.forEach(device => {
              const row = mikrotikDevicesTable.insertRow();
              row.innerHTML = `
                <td>${device.ip}</td>
                <td>${device.name}</td>
                <td>${device.active ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-secondary">Inactive</span>'}</td>
                <td>
                  <button class="btn btn-sm btn-info setActiveBtn" data-id="${device.id}" ${device.active ? 'disabled' : ''}>Set Active</button>
                  <button class="btn btn-sm btn-warning editBtn" data-id="${device.id}">Edit</button>
                  <button class="btn btn-sm btn-danger deleteBtn" data-id="${device.id}">Delete</button>
                </td>
              `;
            });
          });
      }

      document.getElementById('addMikrotikDeviceBtn').addEventListener('click', () => {
        mikrotikDeviceForm.reset();
        document.getElementById('mikrotikDeviceId').value = '';
        mikrotikDeviceModal.find('.modal-title').text('Tambah Perangkat MikroTik');
      });

      saveMikrotikDeviceBtn.addEventListener('click', () => {
        const formData = new FormData(mikrotikDeviceForm);
        const data = Object.fromEntries(formData.entries());
        const id = data.id;
        const url = id ? `/api/mikrotik-devices/${id}` : '/api/mikrotik-devices';
        const method = id ? 'PUT' : 'POST';

        fetch(url, {
          method: method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        })
        .then(res => res.json())
        .then(result => {
          Swal.fire('Success', result.message, 'success');
          mikrotikDeviceModal.modal('hide');
          loadMikrotikDevices();
        })
        .catch(err => Swal.fire('Error', err.message, 'error'));
      });

      mikrotikDevicesTable.addEventListener('click', (e) => {
        const target = e.target;
        const id = target.dataset.id;

        if (target.classList.contains('editBtn')) {
          fetch('/api/mikrotik-devices/${id}', { credentials: 'include' })
            .then(res => res.json())
            .then(device => {
              document.getElementById('mikrotikDeviceId').value = device.id;
              document.getElementById('mikrotikIp').value = device.ip;
              document.getElementById('mikrotikName').value = device.name;
              document.getElementById('mikrotikPassword').value = device.password;
              document.getElementById('mikrotikPort').value = device.port || '8728'; // Set port with fallback
              mikrotikDeviceModal.find('.modal-title').text('Edit Perangkat MikroTik');
              mikrotikDeviceModal.modal('show');
            });
        }

        if (target.classList.contains('deleteBtn')) {
          Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
          }).then((result) => {
            if (result.isConfirmed) {
              fetch(`/api/mikrotik-devices/${id}`, { method: 'DELETE', credentials: 'include' })
                .then(res => res.json())
                .then(result => {
                  Swal.fire('Deleted!', result.message, 'success');
                  loadMikrotikDevices();
                })
                .catch(err => Swal.fire('Error', err.message, 'error'));
            }
          });
        }

        if (target.classList.contains('setActiveBtn')) {
          fetch(`/api/mikrotik-devices/set-active/${id}`, { method: 'POST', credentials: 'include' })
            .then(res => res.json())
            .then(result => {
              Swal.fire('Success', result.message, 'success');
              loadMikrotikDevices();
            })
            .catch(err => Swal.fire('Error', err.message, 'error'));
        }
      });

      loadMikrotikDevices();
    });
    
    // Bank Accounts Management
    window.bankAccounts = [];
    
    function displayBankAccounts() {
      const container = document.getElementById('bankAccountsList');
      if (!container) return;
      
      container.innerHTML = '';
      
      if (window.bankAccounts.length === 0) {
        container.innerHTML = '<div class="alert alert-info">Belum ada rekening bank. Klik tombol "Tambah Rekening" untuk menambahkan.</div>';
        return;
      }
      
      window.bankAccounts.forEach((account, index) => {
        const accountHtml = `
          <div class="card mb-3">
            <div class="card-body">
              <div class="row mb-2">
                <div class="col-md-11">
                  <div class="mb-2">
                    <label class="form-label mb-1 small text-muted">Nama Bank</label>
                    <input type="text" class="form-control" placeholder="Contoh: BCA, BRI, DANA" value="${account.bank || ''}" 
                           onchange="updateBankAccount(${index}, 'bank', this.value)">
                  </div>
                  <div class="mb-2">
                    <label class="form-label mb-1 small text-muted">Nomor Rekening</label>
                    <input type="text" class="form-control" placeholder="Contoh: 1234567890" value="${account.number || ''}"
                           onchange="updateBankAccount(${index}, 'number', this.value)">
                  </div>
                  <div class="mb-0">
                    <label class="form-label mb-1 small text-muted">Atas Nama</label>
                    <input type="text" class="form-control" placeholder="Contoh: MUHAMMAD RAFLI ALDIVA PRATAMA" value="${account.name || ''}"
                           onchange="updateBankAccount(${index}, 'name', this.value)">
                  </div>
                </div>
                <div class="col-md-1 d-flex align-items-center justify-content-center">
                  <button type="button" class="btn btn-danger btn-sm" onclick="removeBankAccount(${index})" title="Hapus Rekening">
                    <i class="fas fa-trash"></i>
                  </button>
                </div>
              </div>
              <div class="mt-3 p-2 bg-light rounded">
                <small class="text-muted d-block mb-1"><strong>Preview format di pesan:</strong></small>
                <small class="d-block" style="white-space: pre-line; font-family: monospace;"> ${account.bank || '[Bank]'}:
${account.number || '[Nomor]'}
a.n ${account.name || '[Nama]'}</small>
              </div>
            </div>
          </div>
        `;
        container.innerHTML += accountHtml;
      });
    }
    
    function addBankAccount() {
      window.bankAccounts.push({
        bank: '',
        number: '',
        name: ''
      });
      displayBankAccounts();
    }
    
    function updateBankAccount(index, field, value) {
      if (window.bankAccounts[index]) {
        window.bankAccounts[index][field] = value;
      }
    }
    
    function removeBankAccount(index) {
      Swal.fire({
        title: 'Hapus Rekening?',
        text: "Rekening bank ini akan dihapus",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, hapus!',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
          window.bankAccounts.splice(index, 1);
          displayBankAccounts();
        }
      });
    }
  </script>

</body>

</html>
